// Copyright 2017 Quip

module.exports = require("quip-apps-webpack-config");
