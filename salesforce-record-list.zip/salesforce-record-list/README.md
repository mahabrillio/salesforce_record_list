# Salesforce Record

Salesforce Record integrates with Salesforce's Lightning APIs to fetch and update data for Account, Opportunity, Contact, and Lead records. This is an example of a complex app using authentication and working with data from an external service.
